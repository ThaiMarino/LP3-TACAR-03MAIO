from django.contrib import admin
from core.models import Cliente, Fabricante, Veiculo, TabelaPreco, Mensalista, Rotativo

#FAZENDO ISSO, DAMOS PERMISSAO PARA O ADMIN VER NOSSAS TABELAS
# Register your models here.
admin.site.register(Cliente)
admin.site.register(Veiculo)
admin.site.register(Fabricante)
admin.site.register(TabelaPreco)
admin.site.register(Mensalista)
admin.site.register(Rotativo)
