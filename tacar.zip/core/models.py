from django.db import models
import math


# Create your models here.


# DECLARANDO AS CLASSES E FORMULARIOS PARA O BANCO DE DADOS
# POR PADRÃO, OS CAMPOS MODEL SÃO OBRIGATÓRIOS. PODEMOS TORNAR OPCIONAL usando blank=True, null=True
# VERBOSE_NAME é para dar nome no formulário

# CRIANDO OS MODELOS DE FORMULÁRIO QUE SERÃO IMPORTADOS PARA FORMS.PY
class Cliente(models.Model):
    objects = None
    nome = models.CharField(max_length=100, verbose_name='Nome')
    endereco = models.CharField(max_length=100, verbose_name='Endereço', blank=True, null=True)
    complemento = models.CharField(max_length=100, verbose_name='Complemento', blank=True, null=True)
    bairro = models.CharField(max_length=50, verbose_name='Bairro', blank=True, null=True)
    cidade = models.CharField(max_length=100, verbose_name='Cidade', blank=True, null=True)
    email = models.EmailField(verbose_name='E-mail')
    fone = models.CharField(max_length=20, blank=True, null=True)
    foto = models.ImageField(upload_to='foto_cliente', blank=True, null=True)

    # PARA MOSTRAR O NOME NO BANCO:
    class Meta:
        verbose_name_plural = 'Clientes'

    def __str__(self):
        return self.nome


class Fabricante(models.Model):
    nome = models.CharField(max_length=50, verbose_name='Fabricante')
    url = models.URLField(verbose_name='Site', blank=True, null=True)
    logo = models.ImageField(upload_to='logo_fabricante', blank=True, null=True)

    # PARA MOSTRAR O NOME NO BANCO:
    def __str__(self):
        return self.nome

    class Meta:
        verbose_name_plural = 'Fabricantes'


# A TABELA VEÍCULO TEM CHAVE ESTRANGEIRA COM FABRICANTE E CLIENTE.
# QUANDO UMA TABELA TEM CHAVE ESTRANGEIRA, ELA DEVE VIR POR ÚLTIMO
class Veiculo(models.Model):
    placa = models.CharField(max_length=8, verbose_name='Placa')
    modelo = models.CharField(max_length=20, verbose_name='Modelo')
    fabricante_id = models.ForeignKey(Fabricante, on_delete=models.CASCADE, verbose_name='Fabricante')
    cliente_id = models.ForeignKey(Cliente, on_delete=models.CASCADE, verbose_name='Cliente')
    cor = models.CharField(max_length=20, verbose_name='Cor', blank=True, null=True)
    ano = models.IntegerField(verbose_name='Ano', blank=True, null=True)
    foto = models.ImageField(upload_to='foto_carro', blank=True, null=True)

    # PARA MOSTRAR O NOME NO BANCO:
    class Meta:
        verbose_name_plural = 'Veículos'

    def __str__(self):
        return f"{self.placa} ({self.modelo})"


class TabelaPreco(models.Model):
    descricao = models.CharField(max_length=100, verbose_name='Descrição')
    valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Valor')

    # PARA MOSTRAR O NOME NO BANCO:
    class Meta:
        verbose_name_plural = 'Tabela de Preços'

    def __str__(self):
        return f'{self.descricao} = {self.valor}'


class Mensalista(models.Model):
    id_veiculo = models.ForeignKey(Veiculo, on_delete=models.CASCADE, verbose_name='Veículo')
    id_tabelapreco = models.ForeignKey(TabelaPreco, on_delete=models.CASCADE, verbose_name='Preço')
    observacoes = models.TextField(verbose_name='Observações', blank=True, null=True)

    class Meta:
        verbose_name_plural = 'Mensalista'

    def __str__(self):
        return f'{self.id_veiculo}-{self.id_tabelapreco}'


class Rotativo(models.Model):
    data_hora_entrada = models.DateTimeField(auto_now=False, verbose_name='Entrada')
    data_hora_saida = models.DateTimeField(auto_now=False, verbose_name='Saída', blank=True, null=True)
    id_veiculo = models.ForeignKey(Veiculo, on_delete=models.CASCADE, verbose_name='Veículo')
    id_tabelapreco = models.ForeignKey(TabelaPreco, on_delete=models.CASCADE, verbose_name='Preço hora')
    total = models.DecimalField(max_digits=10, decimal_places=2, verbose_name= 'Total', blank=True, null=True)
    pago = models.BooleanField(default=False, blank=True, null=True, verbose_name='Pago')
    observacoes = models.TextField(verbose_name='Observações', blank=True, null=True)

    class Meta:
        verbose_name_plural = 'Rotativo'

    def __str__(self):
        return f'{self.data_hora_entrada}-{self.id_veiculo.placa}'

    def calcula_total(self):
        if self.data_hora_saida:
            hora = (self.data_hora_saida - self.data_hora_entrada).total_seconds() / 3600
            print(hora)
            obj = TabelaPreco.objects.get(id=self.id_tabelapreco.pk)
            if hora <= 0.5:
                self.total = obj.valor / 2
            else:
                self.total = math.ceil(hora) * obj.valor
            return self.total
        else:
            return 0.0